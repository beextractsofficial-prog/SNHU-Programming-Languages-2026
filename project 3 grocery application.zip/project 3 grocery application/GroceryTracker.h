// GroceryTracker.h
// Class that stores the item counts and prints the menu reports

#ifndef GROCERY_TRACKER_H
#define GROCERY_TRACKER_H

#include <map>
#include <string>

class GroceryTracker {
public:
    // reads the input file and counts how many times each item shows up
    bool loadItems(const std::string& fileName);

    // returns how many times an item was purchased (0 if it's not in the file)
    int getItemFrequency(const std::string& itemName) const;

    // menu option 2 - prints every item next to its count
    void printAllFrequencies() const;

    // menu option 3 - prints each item with asterisks for its count
    void printHistogram() const;

    // saves all the item counts to a backup file
    bool writeBackupFile(const std::string& fileName = "frequency.dat") const;

private:
    std::map<std::string, int> itemFrequencies;   // item name -> times purchased

    // fixes the capitalization on a word so lookups aren't case sensitive
    static std::string normalizeItem(std::string itemName);
};

#endif
