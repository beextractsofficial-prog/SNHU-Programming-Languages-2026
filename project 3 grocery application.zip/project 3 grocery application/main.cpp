// CS 210 Project Three
//Brianna Bradley
// Corner Grocer - tracks how many times each grocery item was
// purchased during the day based on the store's transaction file

#include <iostream>
#include <limits>
#include <string>
#include "GroceryTracker.h"
using namespace std;

const string INPUT_FILE = "CS210_Project_Three_Input_File.txt";
const string BACKUP_FILE = "frequency.dat";

// prints the menu options
void printMenu() {
    cout << endl;
    cout << "======= Corner Grocer =======" << endl;
    cout << "1. Search for an item" << endl;
    cout << "2. Show all item counts" << endl;
    cout << "3. Show item histogram" << endl;
    cout << "4. Quit" << endl;
    cout << "Choice: ";
}

// keeps asking until the user enters a valid menu number
int getMenuChoice() {
    int choice;
    while (true) {
        if (cin >> choice && choice >= 1 && choice <= 4) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return choice;
        }
        if (cin.eof()) {
            return 4;   // input stream closed, just quit
        }
        cout << "Please enter a number 1-4: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

int main() {
    GroceryTracker tracker;

    // load today's purchases, quit if the file isn't there
    if (!tracker.loadItems(INPUT_FILE)) {
        cout << "Error: couldn't open " << INPUT_FILE << endl;
        return 1;
    }

    // save a backup copy of the counts
    tracker.writeBackupFile(BACKUP_FILE);

    int choice = 0;
    while (choice != 4) {
        printMenu();
        choice = getMenuChoice();
        cout << endl;

        if (choice == 1) {
            string itemName;
            cout << "Item to look up: ";
            getline(cin, itemName);
            cout << itemName << ": " << tracker.getItemFrequency(itemName) << endl;
        }
        else if (choice == 2) {
            tracker.printAllFrequencies();
        }
        else if (choice == 3) {
            tracker.printHistogram();
        }
    }

    cout << "Goodbye!" << endl;
    return 0;
}
