#include "GroceryTracker.h"

#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;

// column width for lining up the reports
const int NAME_WIDTH = 15;

bool GroceryTracker::loadItems(const string& fileName) {
    ifstream inputFile(fileName);
    if (!inputFile.is_open()) {
        return false;
    }

    // add each item to the map, bumping the count if we've seen it already
    string itemName;
    while (inputFile >> itemName) {
        itemFrequencies[normalizeItem(itemName)]++;
    }

    return true;
}

int GroceryTracker::getItemFrequency(const string& itemName) const {
    auto it = itemFrequencies.find(normalizeItem(itemName));
    if (it == itemFrequencies.end()) {
        return 0;
    }
    return it->second;
}

void GroceryTracker::printAllFrequencies() const {
    for (const auto& pair : itemFrequencies) {
        cout << left << setw(NAME_WIDTH) << pair.first << pair.second << endl;
    }
}

void GroceryTracker::printHistogram() const {
    for (const auto& pair : itemFrequencies) {
        cout << left << setw(NAME_WIDTH) << pair.first
             << string(pair.second, '*') << endl;
    }
}

bool GroceryTracker::writeBackupFile(const string& fileName) const {
    ofstream outputFile(fileName);
    if (!outputFile.is_open()) {
        return false;
    }

    for (const auto& pair : itemFrequencies) {
        outputFile << pair.first << " " << pair.second << endl;
    }
    return true;
}

string GroceryTracker::normalizeItem(string itemName) {
    // turn it into "Apples" style so "apples" or "APPLES" still match
    if (!itemName.empty()) {
        itemName[0] = (char)toupper(itemName[0]);
        for (size_t i = 1; i < itemName.size(); i++) {
            itemName[i] = (char)tolower(itemName[i]);
        }
    }
    return itemName;
}
