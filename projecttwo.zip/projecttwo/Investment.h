// Airgead Banking Investment App
// Made by Brianna Bradley
// Investment.h - stores the user's inputs and does the interest math

#ifndef AIRGEAD_BANKING_INVESTMENT_H_
#define AIRGEAD_BANKING_INVESTMENT_H_

#include <vector>

// one row of the report: which year it is, the balance at the end
// of that year, and how much interest was earned during it
struct YearEndReport {
    int year;               // the year number (1 through numberOfYears)
    double yearEndBalance;  // balance on the last day of the year
    double yearEndInterest; // total interest earned that year
};

// Holds the 4 numbers the user types in and handles the month by
// month compound interest math. No cin/cout in here so the math
// stays separate from the interface part.
class Investment {
public:
    // money values are in dollars, rate is a percent (so 5 = 5%)
    Investment(double t_initialInvestment, double t_monthlyDeposit,
               double t_annualInterestRate, int t_numberOfYears);

    double getInitialInvestment() const;
    double getMonthlyDeposit() const;
    double getAnnualInterestRate() const;
    int getNumberOfYears() const;

    // walks through the investment month by month and returns one
    // YearEndReport per year. t_useMonthlyDeposit picks between the
    // "with deposits" report and the "without deposits" one
    std::vector<YearEndReport> calculateYearEndReport(bool t_useMonthlyDeposit) const;

private:
    double m_initialInvestment; // starting amount
    double m_monthlyDeposit;    // gets added at the start of each month
    double m_annualInterestRate;// yearly rate as a percent
    int m_numberOfYears;        // how long the investment grows
};

#endif // AIRGEAD_BANKING_INVESTMENT_H_
