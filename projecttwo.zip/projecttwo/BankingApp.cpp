// Airgead Banking Investment App
// Made by Brianna Bradley
// BankingApp.cpp - implementation of the BankingApp class

#include "BankingApp.h"

#include <cctype>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>

void BankingApp::run() {
    bool runAgain = true;

    // each pass through this loop is one full scenario
    while (runAgain) {
        try {
            displayInputHeader();
            const Investment investment = collectInputs();
            displayContinuePrompt(investment);

            // first report is growth with no deposits, second one
            // adds the monthly deposit in
            printReport(investment, false);
            printReport(investment, true);

            runAgain = promptForAnotherScenario();
        }
        catch (const std::exception& ex) {
            // tell them what went wrong and offer another try instead
            // of crashing. cin.clear() is here so a busted stream
            // doesn't carry over into the next scenario
            std::cout << "\nAn error occurred: " << ex.what() << '\n';
            std::cin.clear();
            runAgain = promptForAnotherScenario();
        }
    }

    std::cout << "\nThank you for using the Airgead Banking investment calculator.\n";
}

void BankingApp::displayInputHeader() const {
    std::cout << "**********************************\n";
    std::cout << "*********** Data Input ***********\n";
    std::cout << "**********************************\n";
}

Investment BankingApp::collectInputs() const {
    const double initialInvestment = promptForPositiveDouble("Initial Investment Amount: $");
    const double monthlyDeposit = promptForPositiveDouble("Monthly Deposit: $");
    const double annualInterestRate = promptForPositiveDouble("Annual Interest (Compounded): %");
    const int numberOfYears = promptForPositiveInt("Number of Years: ");

    return Investment(initialInvestment, monthlyDeposit, annualInterestRate, numberOfYears);
}

double BankingApp::promptForPositiveDouble(const char* t_prompt) const {
    double value = 0.0;

    // keep asking until they type in a number above 0
    while (true) {
        std::cout << t_prompt;
        std::cin >> value;

        // if the input stream itself is dead (like they hit ctrl+z)
        // there's no point asking again
        if (std::cin.eof()) {
            throw std::runtime_error("input stream closed");
        }

        // cin goes into a fail state when they type something that
        // isn't a number
        if (std::cin.fail()) {
            // have to clear the fail flag and dump the rest of the
            // line or every read after this keeps failing too
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "  Invalid entry. Please enter a positive number.\n";
        }
        else if (value <= 0.0) {
            std::cout << "  Value must be greater than zero. Please try again.\n";
        }
        else {
            // toss whatever else is left on the line and take the value
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }
    }
}

int BankingApp::promptForPositiveInt(const char* t_prompt) const {
    double value = 0.0;

    // reading it as a double so something like 5.5 gets caught and
    // rejected instead of silently getting cut down to 5
    while (true) {
        std::cout << t_prompt;
        std::cin >> value;

        if (std::cin.eof()) {
            throw std::runtime_error("input stream closed");
        }
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "  Invalid entry. Please enter a positive whole number.\n";
        }
        else if (value <= 0.0 || std::floor(value) != value) {
            std::cout << "  Value must be a positive whole number. Please try again.\n";
        }
        else {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return static_cast<int>(value); // safe - value is a whole number at this point
        }
    }
}

void BankingApp::displayContinuePrompt(const Investment& t_investment) const {
    // echo their values back in the same layout as the prompts so
    // they can double check them before continuing
    std::cout << "\n**********************************\n";
    std::cout << "*********** Data Input ***********\n";
    std::cout << "**********************************\n";
    std::cout << "Initial Investment Amount: "
              << formatCurrency(t_investment.getInitialInvestment()) << '\n';
    std::cout << "Monthly Deposit: "
              << formatCurrency(t_investment.getMonthlyDeposit()) << '\n';
    std::cout << "Annual Interest (Compounded): %"
              << t_investment.getAnnualInterestRate() << '\n';
    std::cout << "Number of Years: "
              << t_investment.getNumberOfYears() << '\n';

    // gives them a sec to look at their data before the reports
    // take over the screen - all the earlier prompts already ate
    // their newlines so one get() waits for a single enter press
    std::cout << "\nPress Enter to continue ...";
    std::cin.get();
}

void BankingApp::printReport(const Investment& t_investment, bool t_useMonthlyDeposit) const {
    const std::vector<YearEndReport> report =
        t_investment.calculateYearEndReport(t_useMonthlyDeposit);

    if (t_useMonthlyDeposit) {
        std::cout << "\n     Balance and Interest With Additional Monthly Deposits\n";
    }
    else {
        std::cout << "\n   Balance and Interest Without Additional Monthly Deposits\n";
    }

    std::cout << "==========================================================================\n";
    std::cout << std::setw(8) << "Year"
              << std::setw(26) << "Year End Balance"
              << std::setw(30) << "Year End Earned Interest" << '\n';
    std::cout << "==========================================================================\n";

    for (const YearEndReport& row : report) {
        std::cout << std::setw(8) << row.year
                  << std::setw(26) << formatCurrency(row.yearEndBalance)
                  << std::setw(30) << formatCurrency(row.yearEndInterest) << '\n';
    }

    std::cout << "==========================================================================\n";
}

std::string BankingApp::formatCurrency(double t_amount) const {
    std::ostringstream stream;
    stream << '$' << std::fixed << std::setprecision(2) << t_amount;
    return stream.str();
}

bool BankingApp::promptForAnotherScenario() const {
    char answer = 'n';

    // loop until we get a clear yes or no
    while (true) {
        std::cout << "\nWould you like to try a different scenario? (y/n): ";
        std::cin >> answer;

        // if input is closed there's no way to get an answer, so
        // just wrap up instead of looping forever
        if (std::cin.eof()) {
            return false;
        }
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "  Please enter 'y' or 'n'.\n";
            continue;
        }

        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        answer = static_cast<char>(std::tolower(static_cast<unsigned char>(answer)));

        if (answer == 'y') {
            std::cout << '\n';
            return true;
        }
        if (answer == 'n') {
            return false;
        }
        std::cout << "  Please enter 'y' or 'n'.\n";
    }
}
