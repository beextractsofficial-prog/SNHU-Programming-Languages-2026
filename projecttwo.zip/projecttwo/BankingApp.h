// Airgead Banking Investment App
// Made by Brianna Bradley
// BankingApp.h - all the menus, input checking, and report printing

#ifndef AIRGEAD_BANKING_BANKINGAPP_H_
#define AIRGEAD_BANKING_BANKINGAPP_H_

#include <string>

#include "Investment.h"

// This class owns the whole interface: draws the data input screen,
// makes sure the user types valid numbers, prints the two reports,
// and asks if they want to run it again with different values.
class BankingApp {
public:
    // main loop of the program - keeps going until the user says
    // they don't want to try another scenario
    void run();

private:
    // prints the "Data Input" banner above the prompts
    void displayInputHeader() const;

    // asks for the 4 inputs and packs them into an Investment object
    Investment collectInputs() const;

    // asks for a positive number, keeps asking until they give a
    // valid one. t_prompt is the label shown in front of the input
    double promptForPositiveDouble(const char* t_prompt) const;

    // same idea but for years, which has to be a whole number
    int promptForPositiveInt(const char* t_prompt) const;

    // shows the values they entered and waits for an enter press so
    // they can actually look at them before the reports print
    void displayContinuePrompt(const Investment& t_investment) const;

    // prints one of the reports - t_useMonthlyDeposit decides
    // which of the two versions we show
    void printReport(const Investment& t_investment, bool t_useMonthlyDeposit) const;

    // turns something like 1234.5 into "$1234.50" so the
    // report columns stay lined up
    std::string formatCurrency(double t_amount) const;

    // asks if they want to run another scenario, true = yes
    bool promptForAnotherScenario() const;
};

#endif // AIRGEAD_BANKING_BANKINGAPP_H_
