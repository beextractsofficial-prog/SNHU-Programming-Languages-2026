// Airgead Banking Investment App
// Made by Brianna Bradley
// Investment.cpp - implementation of the Investment class

#include "Investment.h"

// 12 months in a year - used to turn the annual rate into a monthly
// one and to know when a full year has gone by
const int MONTHS_IN_YEAR = 12;

Investment::Investment(double t_initialInvestment, double t_monthlyDeposit,
                       double t_annualInterestRate, int t_numberOfYears)
    : m_initialInvestment(t_initialInvestment),
      m_monthlyDeposit(t_monthlyDeposit),
      m_annualInterestRate(t_annualInterestRate),
      m_numberOfYears(t_numberOfYears) {}

double Investment::getInitialInvestment() const {
    return m_initialInvestment;
}

double Investment::getMonthlyDeposit() const {
    return m_monthlyDeposit;
}

double Investment::getAnnualInterestRate() const {
    return m_annualInterestRate;
}

int Investment::getNumberOfYears() const {
    return m_numberOfYears;
}

std::vector<YearEndReport> Investment::calculateYearEndReport(bool t_useMonthlyDeposit) const {
    std::vector<YearEndReport> report;
    report.reserve(static_cast<size_t>(m_numberOfYears)); // we already know exactly how many rows we'll need

    // monthly rate = (rate / 100) / 12
    // /100 turns the percent into a decimal, /12 spreads it over the months
    const double monthlyInterestRate = (m_annualInterestRate / 100.0) / MONTHS_IN_YEAR;

    double balance = m_initialInvestment; // opening balance for month 1
    double yearlyInterest = 0.0;          // running total of interest for the current year

    const int totalMonths = m_numberOfYears * MONTHS_IN_YEAR;

    for (int month = 1; month <= totalMonths; ++month) {
        // the deposit only gets added when we're doing the
        // "with deposits" version of the report
        const double depositedAmount = t_useMonthlyDeposit ? m_monthlyDeposit : 0.0;
        const double total = balance + depositedAmount;

        // interest = (opening + deposited) * monthly rate
        const double interest = total * monthlyInterestRate;

        // closing balance carries over as next month's opening
        balance = total + interest;
        yearlyInterest += interest;

        // every 12th month a year is done, so save the row and
        // reset the interest counter for the next year
        if (month % MONTHS_IN_YEAR == 0) {
            report.push_back(YearEndReport{month / MONTHS_IN_YEAR, balance, yearlyInterest});
            yearlyInterest = 0.0;
        }
    }

    return report;
}
