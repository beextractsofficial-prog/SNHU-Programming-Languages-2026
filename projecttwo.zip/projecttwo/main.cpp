// Airgead Banking Investment App
// Made by Brianna Bradley
// main.cpp - entry point, just starts the app

#include <iostream>
#include <stdexcept>

#include "BankingApp.h"

int main() {
    try {
        BankingApp app; // this object pretty much runs everything
        app.run();
    }
    catch (const std::exception& ex) {
        // last resort catch - if something still breaks, at least
        // print why instead of dying with no message
        std::cerr << "Fatal error: " << ex.what() << '\n';
        return 1;
    }

    return 0;
}
